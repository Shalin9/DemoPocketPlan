package vcmsa.projects.pocketplanpoe

data class Category(val id: String = "",
                    val name: String = "")
